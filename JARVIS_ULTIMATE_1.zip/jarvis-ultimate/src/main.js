const { app, BrowserWindow, Tray, Menu, ipcMain, shell, nativeImage } = require('electron');
const path = require('path');
const https = require('https');
const fs = require('fs');
const { spawn } = require('child_process');

let mainWindow, tray, speechProcess;
app.isQuiting = false;

app.commandLine.appendSwitch('enable-features', 'WebSpeechAPI');
app.commandLine.appendSwitch('enable-speech-dispatcher');

const settingsPath = path.join(app.getPath('userData'), 'settings.json');

function loadSettings() {
  try {
    if (fs.existsSync(settingsPath)) return JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
  } catch {}
  return {
    aiProvider: 'gemini',
    geminiKey: '',
    openaiKey: '',
    claudeKey: '',
    theme: 'blue',
    stayInTray: true,
    systemVoice: '',
    micDeviceId: 'default',
    micSensitivity: 50,
    language: 'en-US'
  };
}

function saveSettings(s) {
  try { fs.writeFileSync(settingsPath, JSON.stringify(s, null, 2)); } catch(e) {}
}

let settings = loadSettings();

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 500, height: 880,
    resizable: false, frame: false, transparent: true,
    webPreferences: { nodeIntegration: true, contextIsolation: false, webSecurity: false },
    title: 'J.A.R.V.I.S.'
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  mainWindow.on('close', (e) => {
    if (settings.stayInTray && !app.isQuiting) { e.preventDefault(); mainWindow.hide(); }
  });
}

function createTray() {
  const iconPath = path.join(__dirname, 'assets', 'tray.png');
  let icon;
  try { icon = nativeImage.createFromPath(iconPath); } catch { icon = nativeImage.createEmpty(); }
  tray = new Tray(icon);
  tray.setToolTip('J.A.R.V.I.S. — Online');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Show JARVIS', click: () => { mainWindow.show(); mainWindow.focus(); } },
    { label: 'Hide', click: () => mainWindow.hide() },
    { type: 'separator' },
    { label: 'Quit', click: () => { app.isQuiting = true; app.exit(0); } }
  ]));
  tray.on('click', () => mainWindow.isVisible() ? mainWindow.hide() : mainWindow.show());
}

// ── Windows Speech Recognition ────────────────────────────
function startSpeech(lang) {
  if (speechProcess) { try { speechProcess.kill(); } catch {} speechProcess = null; }

  const script = `
Add-Type -AssemblyName System.Speech
$r = $null
try {
  $culture = [System.Globalization.CultureInfo]"${lang || 'en-US'}"
  $r = New-Object System.Speech.Recognition.SpeechRecognitionEngine($culture)
} catch {
  $r = New-Object System.Speech.Recognition.SpeechRecognitionEngine
}
$r.SetInputToDefaultAudioDevice()
$g = New-Object System.Speech.Recognition.DictationGrammar
$r.LoadGrammar($g)
while($true){
  try {
    $res = $r.Recognize([TimeSpan]::FromSeconds(10))
    if($res -ne $null -and $res.Text.Trim() -ne ""){
      Write-Output $res.Text.Trim()
      [Console]::Out.Flush()
    }
  } catch {}
}`;

  const ps = path.join(app.getPath('temp'), 'jarvis_sr.ps1');
  fs.writeFileSync(ps, script, 'utf8');

  speechProcess = spawn('powershell.exe', ['-ExecutionPolicy','Bypass','-NonInteractive','-File',ps]);
  speechProcess.stdout.on('data', (d) => {
    const txt = d.toString().trim();
    if (txt && mainWindow) mainWindow.webContents.send('speech', txt);
  });
  speechProcess.on('close', () => {
    if (!app.isQuiting) setTimeout(() => startSpeech(settings.language), 2000);
  });
}

// ── Gemini API ────────────────────────────────────────────
function callGemini(messages, key) {
  return new Promise((resolve) => {
    // Try multiple models in case one is rate limited
    const models = ['gemini-2.0-flash', 'gemini-1.5-flash', 'gemini-1.5-pro'];
    let modelIndex = 0;

    function tryModel() {
      const model = models[modelIndex];
      const contents = messages.map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }]
      }));
      const body = JSON.stringify({
        system_instruction: { parts: [{ text: SYSTEM_PROMPT }] },
        contents,
        generationConfig: { maxOutputTokens: 600, temperature: 0.85 }
      });
      const req = https.request({
        hostname: 'generativelanguage.googleapis.com',
        path: `/v1beta/models/${model}:generateContent?key=${key}`,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
      }, (res) => {
        let data = '';
        res.on('data', c => data += c);
        res.on('end', () => {
          try {
            const p = JSON.parse(data);
            if (p.error && p.error.code === 429 && modelIndex < models.length - 1) {
              modelIndex++;
              setTimeout(tryModel, 500);
              return;
            }
            if (p.error) { resolve(`API error: ${p.error.message}`); return; }
            resolve(p.candidates?.[0]?.content?.parts?.[0]?.text || 'No response, sir.');
          } catch { resolve('Error parsing response, sir.'); }
        });
      });
      req.on('error', (e) => resolve(`Connection failed: ${e.message}`));
      req.setTimeout(20000, () => { req.destroy(); resolve('Request timed out, sir.'); });
      req.write(body);
      req.end();
    }
    tryModel();
  });
}

// ── OpenAI API ────────────────────────────────────────────
function callOpenAI(messages, key) {
  return new Promise((resolve) => {
    const msgs = [{ role: 'system', content: SYSTEM_PROMPT }, ...messages];
    const body = JSON.stringify({ model: 'gpt-4o-mini', messages: msgs, max_tokens: 600 });
    const req = https.request({
      hostname: 'api.openai.com',
      path: '/v1/chat/completions',
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}`, 'Content-Length': Buffer.byteLength(body) }
    }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try {
          const p = JSON.parse(data);
          if (p.error) { resolve(`API error: ${p.error.message}`); return; }
          resolve(p.choices?.[0]?.message?.content || 'No response, sir.');
        } catch { resolve('Error parsing response, sir.'); }
      });
    });
    req.on('error', e => resolve(`Connection failed: ${e.message}`));
    req.setTimeout(20000, () => { req.destroy(); resolve('Request timed out, sir.'); });
    req.write(body);
    req.end();
  });
}

// ── Claude API ────────────────────────────────────────────
function callClaude(messages, key) {
  return new Promise((resolve) => {
    const body = JSON.stringify({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 600,
      system: SYSTEM_PROMPT,
      messages
    });
    const req = https.request({
      hostname: 'api.anthropic.com',
      path: '/v1/messages',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
        'Content-Length': Buffer.byteLength(body)
      }
    }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try {
          const p = JSON.parse(data);
          if (p.error) { resolve(`API error: ${p.error.message}`); return; }
          resolve(p.content?.[0]?.text || 'No response, sir.');
        } catch { resolve('Error parsing response, sir.'); }
      });
    });
    req.on('error', e => resolve(`Connection failed: ${e.message}`));
    req.setTimeout(20000, () => { req.destroy(); resolve('Request timed out, sir.'); });
    req.write(body);
    req.end();
  });
}

const SYSTEM_PROMPT = `You are J.A.R.V.I.S., Tony Stark's AI assistant. Female personality — elegant, brilliant, witty, precise.
Rules:
1. Single word or very short phrase (not a question): respond "What do you have in mind today, sir?" then ask ONE sharp follow-up question.
2. Question or request: answer fully, intelligently, concisely.
3. Always sophisticated tone. Call user "sir" occasionally. Max 2-3 sentences for simple things, more for complex ones.`;

// ── IPC Handlers ──────────────────────────────────────────
ipcMain.handle('ask-ai', async (e, { messages, provider, keys }) => {
  if (provider === 'gemini' && keys.gemini) return await callGemini(messages, keys.gemini);
  if (provider === 'openai' && keys.openai) return await callOpenAI(messages, keys.openai);
  if (provider === 'claude' && keys.claude) return await callClaude(messages, keys.claude);
  return 'No API key configured for this provider, sir. Please check settings.';
});

ipcMain.handle('get-settings', () => settings);
ipcMain.handle('save-settings', (e, s) => { settings = { ...settings, ...s }; saveSettings(settings); return true; });
ipcMain.handle('start-speech', (e, lang) => { startSpeech(lang); return true; });
ipcMain.handle('minimize', () => mainWindow.hide());
ipcMain.handle('quit', () => { app.isQuiting = true; app.exit(0); });
ipcMain.handle('open-url', (e, url) => shell.openExternal(url));

app.whenReady().then(() => { createWindow(); createTray(); });
app.on('window-all-closed', e => e.preventDefault());
app.on('before-quit', () => { app.isQuiting = true; if (speechProcess) try { speechProcess.kill(); } catch {} });
